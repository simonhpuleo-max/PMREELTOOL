import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 100" className={className} aria-label="NEWS→REELS Logo">
    <text
      x="200"
      y="55"
      dominantBaseline="middle"
      textAnchor="middle"
      fontFamily="sans-serif"
      fontSize="50"
      fontWeight="bold"
      fill="currentColor"
      letterSpacing="-1"
    >
      NEWS<tspan fill="#C4A267" dx="10" dy="-2">→</tspan><tspan dx="10">REELS</tspan>
    </text>
  </svg>
);
