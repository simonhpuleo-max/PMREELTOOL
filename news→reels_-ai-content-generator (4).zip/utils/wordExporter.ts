import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import { Script, NewsItem } from '../types';
import { Language } from '../utils/translations';

const translations = {
    title: {
        es: "Guion Viral para Reel - NEWS→REELS",
        en: "Viral Reel Script - NEWS→REELS",
        pt: "Roteiro Viral para Reel - NEWS→REELS",
    },
    originalNews: {
        es: "Noticia Original",
        en: "Original News",
        pt: "Notícia Original",
    },
    source: {
        es: "Fuente",
        en: "Source",
        pt: "Fonte",
    },
    date: {
        es: "Fecha",
        en: "Date",
        pt: "Data",
    },
    detailedScript: {
        es: "Guion Detallado",
        en: "Detailed Script",
        pt: "Roteiro Detalhado",
    },
    hook: {
        es: "🎬 Hook (0-8s)",
        en: "🎬 Hook (0-8s)",
        pt: "🎬 Gancho (0-8s)",
    },
    development: {
        es: "💡 Desarrollo",
        en: "💡 Development",
        pt: "💡 Desenvolvimento",
    },
    cta: {
        es: "🚀 Cierre (CTA)",
        en: "🚀 Closing (CTA)",
        pt: "🚀 Fechamento (CTA)",
    },
    cleanAudio: {
        es: "Texto Limpio para Audio (TTS)",
        en: "Clean Text for Audio (TTS)",
        pt: "Texto Limpo para Áudio (TTS)",
    },
    suggestions: {
        es: "Sugerencias Adicionales",
        en: "Additional Suggestions",
        pt: "Sugestões Adicionais",
    },
    videoTitle: {
        es: "Título del Video",
        en: "Video Title",
        pt: "Título do Vídeo",
    },
    hashtags: {
        es: "Hashtags",
        en: "Hashtags",
        pt: "Hashtags",
    },
    thumbnail: {
        es: "Idea de Miniatura",
        en: "Thumbnail Idea",
        pt: "Ideia de Miniatura",
    },
    filenamePrefix: {
        es: "Guion",
        en: "Script",
        pt: "Roteiro",
    }
};

const t = (key: keyof typeof translations, lang: Language) => translations[key][lang];

export const exportScriptToDocx = async (script: Script, newsItem: NewsItem, language: Language) => {
    const doc = new Document({
        styles: {
            paragraphStyles: [
                 {
                    id: "default",
                    name: "Normal",
                    basedOn: "Normal",
                    next: "Normal",
                    quickFormat: true,
                    run: {
                        size: 22, // 11pt
                        font: "Calibri",
                    },
                },
                {
                    id: "title",
                    name: "Title",
                    basedOn: "Normal",
                    next: "Normal",
                    run: {
                        size: 44, // 22pt
                        bold: true,
                    },
                     paragraph: {
                        spacing: { after: 300 },
                        alignment: AlignmentType.CENTER,
                    },
                },
                 {
                    id: "heading2",
                    name: "Heading 2",
                    basedOn: "Normal",
                    next: "Normal",
                    run: {
                        size: 28, // 14pt
                        bold: true,
                        color: "2E74B5",
                    },
                     paragraph: {
                        spacing: { after: 150, before: 300 },
                    },
                },
            ],
        },
        sections: [{
            properties: {},
            children: [
                new Paragraph({
                    text: t('title', language),
                    style: "title",
                }),

                new Paragraph({ style: "heading2", text: t('originalNews', language) }),
                new Paragraph({
                    children: [ new TextRun({ text: newsItem.headline, bold: true, size: 24 }) ],
                    spacing: { after: 100, before: 200 },
                }),
                new Paragraph({
                    children: [
                        new TextRun({ text: `${t('source', language)}: ${newsItem.source} - ${t('date', language)}: ${newsItem.date}`, italics: true }),
                    ],
                }),
                new Paragraph({
                    text: newsItem.summary,
                    spacing: { after: 400 },
                }),

                new Paragraph({ style: "heading2", text: t('detailedScript', language) }),
                new Paragraph({ children: [ new TextRun({ text: t('hook', language), bold: true, size: 24 })], spacing: { after: 100, before: 200 } }),
                new Paragraph(script.detailedScript.hook),
                new Paragraph({ children: [ new TextRun({ text: t('development', language), bold: true, size: 24 })], spacing: { after: 100, before: 200 } }),
                new Paragraph(script.detailedScript.development),
                new Paragraph({ children: [ new TextRun({ text: t('cta', language), bold: true, size: 24 })], spacing: { after: 100, before: 200 } }),
                new Paragraph(script.detailedScript.cta),

                new Paragraph({ style: "heading2", text: t('cleanAudio', language) }),
                new Paragraph({
                    text: script.cleanAudioText,
                    italics: true,
                    spacing: { after: 400 },
                }),

                new Paragraph({ style: "heading2", text: t('suggestions', language) }),
                new Paragraph({ children: [ new TextRun({ text: t('videoTitle', language), bold: true, size: 24 })], spacing: { after: 100, before: 200 } }),
                new Paragraph(script.suggestions.title),
                new Paragraph({ children: [ new TextRun({ text: t('hashtags', language), bold: true, size: 24 })], spacing: { after: 100, before: 200 } }),
                new Paragraph(script.suggestions.hashtags.join(', ')),
                new Paragraph({ children: [ new TextRun({ text: t('thumbnail', language), bold: true, size: 24 })], spacing: { after: 100, before: 200 } }),
                new Paragraph(script.suggestions.thumbnailIdea),
            ],
        }],
    });
    
    // Sanitize filename
    const filename = `${t('filenamePrefix', language)}-${newsItem.headline.substring(0, 30).replace(/[^a-z0-9]/gi, '_')}.docx`;

    const blob = await Packer.toBlob(doc);
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
};