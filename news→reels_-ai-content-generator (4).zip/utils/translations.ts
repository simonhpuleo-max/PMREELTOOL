export type Language = 'es' | 'en' | 'pt';

// FIX: Export the translations object so it can be imported and used for typing.
export const translations = {
    subtitle: {
        es: "Transforma noticias, texto o videos de Real Estate en guiones virales.",
        en: "Transform real estate news, text, or videos into viral scripts.",
        pt: "Transforme notícias, textos ou vídeos do mercado imobiliário em roteiros virais.",
    },
    errorTitle: {
        es: "Error:",
        en: "Error:",
        pt: "Erro:",
    },
    step1Title: {
        es: "Paso 1: Elige tu fuente",
        en: "Step 1: Choose Your Source",
        pt: "Passo 1: Escolha Sua Fonte",
    },
    tabNews: {
        es: "Buscar Novedades",
        en: "Search Updates",
        pt: "Buscar Novidades",
    },
    tabText: {
        es: "Texto Propio",
        en: "Your Text",
        pt: "Seu Texto",
    },
    tabVideo: {
        es: "Subir Video",
        en: "Upload Video",
        pt: "Enviar Vídeo",
    },
    newsDescription: {
        es: "Busca noticias, eventos y novedades locales con IA para generar un guion.",
        en: "Search for local news, events, and updates with AI to generate a script.",
        pt: "Pesquise notícias, eventos e novidades locais com IA para gerar um roteiro.",
    },
    newsButton: {
        es: "Buscar Novedades",
        en: "Search for Updates",
        pt: "Buscar Novidades",
    },
    newsLoading: {
        es: "Buscando novedades en Orlando y Florida Central...",
        en: "Searching for updates in Orlando and Central Florida...",
        pt: "Buscando novidades em Orlando e na Flórida Central...",
    },
    customTextPlaceholder: {
        es: "...o pega tu propio texto, idea o URL aquí.",
        en: "...or paste your own text, idea, or URL here.",
        pt: "...ou cole seu próprio texto, ideia ou URL aqui.",
    },
    customTextButton: {
        es: "Crear Guion desde Texto",
        en: "Create Script from Text",
        pt: "Criar Roteiro do Texto",
    },
    videoDescription: {
        es: "Sube un video (máx. 1 hora) para transcribir su audio y generar un guion.",
        en: "Upload a video (max 1 hour) to transcribe its audio and generate a script.",
        pt: "Envie um vídeo (máx. 1 hora) para transcrever o áudio e gerar um roteiro.",
    },
    videoSelect: {
        es: "Seleccionar Video",
        en: "Select Video",
        pt: "Selecionar Vídeo",
    },
    videoFileSelected: {
        es: "Archivo:",
        en: "File:",
        pt: "Arquivo:",
    },
    videoDropzone: {
        es: "Arrastra y suelta o haz clic para buscar",
        en: "Drag and drop or click to browse",
        pt: "Arraste e solte ou clique para procurar",
    },
    videoButton: {
        es: "Crear Guion desde Video",
        en: "Create Script from Video",
        pt: "Criar Roteiro do Vídeo",
    },
    step2Title: {
        es: "Paso 2: Selecciona un tema para generar el guion",
        en: "Step 2: Select a topic to generate the script",
        pt: "Passo 2: Selecione um tópico para gerar o roteiro",
    },
    generatingScript: {
        es: "Generando un guion viral para",
        en: "Generating a viral script for",
        pt: "Gerando um roteiro viral para",
    },
    transcribingScript: {
        es: "Transcribiendo y generando guion para",
        en: "Transcribing and generating script for",
        pt: "Transcrevendo e gerando roteiro para",
    },
    backButton: {
        es: "Volver a empezar",
        en: "Start Over",
        pt: "Começar de Novo",
    },
    basedOn: {
        es: "Basado en:",
        en: "Based on:",
        pt: "Baseado em:",
    },
    listenButton: {
        es: "Escuchar Guion",
        en: "Listen to Script",
        pt: "Ouvir Roteiro",
    },
    generatingAudio: {
        es: "Generando...",
        en: "Generating...",
        pt: "Gerando...",
    },
    stopAudio: {
        es: "Detener",
        en: "Stop",
        pt: "Parar",
    },
    editButton: {
        es: "Editar con IA",
        en: "Edit with AI",
        pt: "Editar com IA",
    },
    downloadButton: {
        es: "Descargar (.docx)",
        en: "Download (.docx)",
        pt: "Baixar (.docx)",
    },
    editPanelTitle: {
        es: "Edita tu guion con un comando:",
        en: "Edit your script with a command:",
        pt: "Edite seu roteiro com um comando:",
    },
    editPanelPlaceholder: {
        es: "Ej: 'Haz el hook más corto y directo' o 'Cambia el CTA para que pidan una guía gratis'",
        en: "e.g., 'Make the hook shorter and more direct' or 'Change the CTA to ask for a free guide'",
        pt: "Ex: 'Torne o gancho mais curto e direto' ou 'Mude o CTA para pedir um guia gratuito'",
    },
    regenerateButton: {
        es: "Re-generar Guion",
        en: "Regenerate Script",
        pt: "Gerar Roteiro Novamente",
    },
    detailedScriptTitle: {
        es: "Guion Detallado",
        en: "Detailed Script",
        pt: "Roteiro Detalhado",
    },
    hookTitle: {
        es: "Hook (0-8s):",
        en: "Hook (0-8s):",
        pt: "Gancho (0-8s):",
    },
    developmentTitle: {
        es: "Desarrollo:",
        en: "Development:",
        pt: "Desenvolvimento:",
    },
    ctaTitle: {
        es: "Cierre (CTA):",
        en: "Closing (CTA):",
        pt: "Fechamento (CTA):",
    },
    audioTextTitle: {
        es: "Texto para Audio (TTS)",
        en: "Text for Audio (TTS)",
        pt: "Texto para Áudio (TTS)",
    },
    suggestionsTitle: {
        es: "Sugerencias",
        en: "Suggestions",
        pt: "Sugestões",
    },
    hashtagsTitle: {
        es: "Hashtags:",
        en: "Hashtags:",
        pt: "Hashtags:",
    },
    thumbnailTitle: {
        es: "Idea de Miniatura:",
        en: "Thumbnail Idea:",
        pt: "Ideia de Miniatura:",
    },
    emptyContentError: {
        es: "Por favor, introduce algún contenido.",
        en: "Please enter some content.",
        pt: "Por favor, insira algum conteúdo.",
    },
    emptyVideoError: {
        es: "Por favor, selecciona un archivo de video.",
        en: "Please select a video file.",
        pt: "Por favor, selecione um arquivo de vídeo.",
    },
    invalidVideoError: {
        es: "Por favor, selecciona un archivo de video válido.",
        en: "Please select a valid video file.",
        pt: "Por favor, selecione um arquivo de vídeo válido.",
    },
    emptyScriptError: {
        es: "El guion generado estaba vacío.",
        en: "The generated script was empty.",
        pt: "O roteiro gerado estava vazio.",
    },
    emptyVideoScriptError: {
        es: "El guion generado desde el video estaba vacío.",
        en: "The script generated from the video was empty.",
        pt: "O roteiro gerado a partir do vídeo estava vazio.",
    },
    editScriptError: {
        es: "La edición del guion devolvió un resultado vacío.",
        en: "Editing the script returned an empty result.",
        pt: "A edição do roteiro retornou um resultado vazio.",
    },
    audioPlayError: {
        es: "No se pudo reproducir el audio.",
        en: "Could not play the audio.",
        pt: "Não foi possível reproduzir o áudio.",
    },
    unknownError: {
        es: "Ocurrió un error desconocido.",
        en: "An unknown error occurred.",
        pt: "Ocorreu um erro desconhecido.",
    }
};

export const t = (key: keyof typeof translations, lang: Language): string => {
    return translations[key][lang] || translations[key]['en'];
};