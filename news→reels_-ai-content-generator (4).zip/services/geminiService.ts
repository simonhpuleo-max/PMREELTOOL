import { GoogleGenAI, Modality } from "@google/genai";
import { NewsItem, Script } from '../types';
import { Language } from '../utils/translations';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const NEWS_MODEL = 'gemini-2.5-flash';
const SCRIPT_MODEL = 'gemini-2.5-pro';
const VIDEO_MODEL = 'gemini-2.5-pro';
const TTS_MODEL = 'gemini-2.5-flash-preview-tts';

const newsKeywords = {
    es: { headline: 'Titular', source: 'Fuente', date: 'Fecha', summary: 'Resumen' },
    en: { headline: 'Headline', source: 'Source', date: 'Date', summary: 'Summary' },
    pt: { headline: 'Título', source: 'Fonte', date: 'Data', summary: 'Resumo' },
};

const scriptKeywords = {
    es: { hook: "Hook \\(Gancho inicial - hasta 8 segundos\\):", development: "Desarrollo:", cta: "Cierre \\(CTA\\):", cleanAudio: "TEXTO LIMPIO PARA AUDIO:", suggestions: "SUGERENCIAS ADICIONALES:", title: "Título para el video:", hashtags: "Hashtags:", thumbnail: "Idea de Miniatura \\(Thumbnail\\):" },
    en: { hook: "Hook \\(Opening hook - up to 8 seconds\\):", development: "Development:", cta: "Closing \\(CTA\\):", cleanAudio: "CLEAN TEXT FOR AUDIO:", suggestions: "ADDITIONAL SUGGESTIONS:", title: "Video Title:", hashtags: "Hashtags:", thumbnail: "Thumbnail Idea:" },
    pt: { hook: "Gancho \\(Gancho inicial - até 8 segundos\\):", development: "Desenvolvimento:", cta: "Fechamento \\(CTA\\):", cleanAudio: "TEXTO LIMPO PARA ÁUDIO:", suggestions: "SUGESTÕES ADICIONAIS:", title: "Título para o vídeo:", hashtags: "Hashtags:", thumbnail: "Ideia de Miniatura \\(Thumbnail\\):" }
};

function parseNews(text: string, language: Language): NewsItem[] {
  try {
    const newsItems: NewsItem[] = [];
    const articles = text.split(/\d+\.\s+/).filter(Boolean);
    const keywords = newsKeywords[language];

    articles.forEach(article => {
      const headlineMatch = article.match(new RegExp(`${keywords.headline}:\\s*(.*)`));
      const sourceMatch = article.match(new RegExp(`${keywords.source}:\\s*(.*)`));
      const dateMatch = article.match(new RegExp(`${keywords.date}:\\s*(.*)`));
      const summaryMatch = article.match(new RegExp(`${keywords.summary}:\\s*(.*)`));

      if (headlineMatch && sourceMatch && dateMatch && summaryMatch) {
        newsItems.push({
          headline: headlineMatch[1].trim(),
          source: sourceMatch[1].trim(),
          date: dateMatch[1].trim(),
          summary: summaryMatch[1].trim(),
        });
      }
    });
    return newsItems;
  } catch (error) {
    console.error("Failed to parse news items:", error);
    return [];
  }
}

function parseScript(text: string, language: Language): Script | null {
  try {
    const keywords = scriptKeywords[language];
    const hookMatch = text.match(new RegExp(`\\*\\*${keywords.hook}\\*\\*\\s*[-*]?\\s*([\\s\\S]*?)(?=\\s*\\*\\*${keywords.development}\\*\\*|$)`));
    const developmentMatch = text.match(new RegExp(`\\*\\*${keywords.development}\\*\\*\\s*[-*]?\\s*([\\s\\S]*?)(?=\\s*\\*\\*${keywords.cta}\\*\\*\\s*|$)`));
    const ctaMatch = text.match(new RegExp(`\\*\\*${keywords.cta}\\*\\*\\s*[-*]?\\s*([\\s\\S]*?)(?=\\s*\\*\\*${keywords.cleanAudio}\\*\\*|$)`));
    const cleanAudioTextMatch = text.match(new RegExp(`\\*\\*${keywords.cleanAudio}\\*\\*\\s*\\n?([\\s\\S]*?)(?=\\s*\\*\\*${keywords.suggestions}\\*\\*|$)`));
    const titleMatch = text.match(new RegExp(`\\*\\*${keywords.title}\\*\\*\\s*([\\s\\S]*?)(?=\\s*.*?\\*\\*${keywords.hashtags}\\*\\*|$)`));
    const hashtagsMatch = text.match(new RegExp(`\\*\\*${keywords.hashtags}\\*\\*\\s*\\n?([\\s\\S]*?)(?=\\s*.*?\\*\\*${keywords.thumbnail}\\*\\*|$)`));
    const thumbnailIdeaMatch = text.match(new RegExp(`\\*\\*${keywords.thumbnail}\\*\\*\\s*([\\s\\S]*)`));

    if (!hookMatch || !developmentMatch || !ctaMatch || !cleanAudioTextMatch || !titleMatch || !hashtagsMatch || !thumbnailIdeaMatch) {
        console.error("Failed to parse script, one or more sections not found.");
        console.log({ text, lang: language, hookMatch: !!hookMatch, developmentMatch: !!developmentMatch, ctaMatch: !!ctaMatch, cleanAudioTextMatch: !!cleanAudioTextMatch, titleMatch: !!titleMatch, hashtagsMatch: !!hashtagsMatch, thumbnailIdeaMatch: !!thumbnailIdeaMatch });
        return null;
    }
    
    const hashtags = hashtagsMatch[1].split('\n').map(h => h.trim().replace(/^[-*]\s*/, '')).filter(Boolean);
    const cleanAudioText = cleanAudioTextMatch[1].replace(/\[.*?\]/g, '').replace(/\(.*?00:\d{2}.*?\)/g, '').replace(/[\r\n]+/g, ' ').trim();

    return {
      detailedScript: { hook: hookMatch[1].trim(), development: developmentMatch[1].trim(), cta: ctaMatch[1].trim() },
      cleanAudioText: cleanAudioText,
      suggestions: { title: titleMatch[1].trim(), hashtags: hashtags, thumbnailIdea: thumbnailIdeaMatch[1].trim() },
    };
  } catch (error) {
    console.error("Failed to parse script:", error);
    return null;
  }
}

const newsPrompts = {
    es: `Eres NEWS→REELS, una IA experta en contenido local de Orlando y Florida Central para profesionales de Real Estate. Tu tarea es encontrar una mezcla de contenido fresco y relevante que puedan compartir en sus redes sociales para conectar con la comunidad. Busca entre 5 y 8 temas variados del último mes, incluyendo: 1. **Noticias clave de Real Estate y Mortgage:** Tasas de interés, nuevas regulaciones, mercado local. 2. **Eventos importantes:** Festivales, conciertos, eventos deportivos, inauguraciones en Orlando y Florida Central. 3. **Lugares de interés:** Nuevos restaurantes, parques, atracciones o lugares únicos que estén de moda. 4. **Novedades locales generales:** Anuncios importantes de la ciudad, proyectos de desarrollo, o cualquier cosa que sea tema de conversación en la comunidad. Para cada tema, formatea la salida EXACTAMENTE así, numerando cada uno:\n1. Titular: [Un titular atractivo del tema]\nFuente: [Nombre del sitio web, blog o fuente oficial]\nFecha: [Fecha de publicación o fecha del evento]\nResumen: [Un resumen muy breve de no más de dos frases]\n\nResponde siempre en español. No agregues ninguna introducción o conclusión, solo la lista de temas.`,
    en: `You are NEWS→REELS, an AI expert in local Orlando and Central Florida content for Real Estate professionals. Your task is to find a mix of fresh, relevant content they can share on social media to connect with the community. Find 5 to 8 varied topics from the last month, including: 1. **Key Real Estate & Mortgage News:** Interest rates, new regulations, local market trends. 2. **Major Events:** Festivals, concerts, sports events, openings in Orlando and Central Florida. 3. **Places of Interest:** New restaurants, parks, attractions, or unique trending spots. 4. **General Local News:** Important city announcements, development projects, or anything that's a topic of conversation in the community. For each topic, format the output EXACTLY like this, numbering each one:\n1. Headline: [An attractive headline for the topic]\nSource: [Name of the website, blog, or official source]\nDate: [Publication date or event date]\nSummary: [A very brief summary of no more than two sentences]\n\nAlways respond in English. Do not add any introduction or conclusion, just the list of topics.`,
    pt: `Você é NEWS→REELS, um especialista de IA em conteúdo local de Orlando e Flórida Central para profissionais do setor imobiliário. Sua tarefa é encontrar uma mistura de conteúdo novo e relevante que eles possam compartilhar nas redes sociais para se conectar com a comunidade. Encontre de 5 a 8 tópicos variados do último mês, incluindo: 1. **Notícias Chave de Imóveis e Hipotecas:** Taxas de juros, novas regulamentações, mercado local. 2. **Eventos Importantes:** Festivais, shows, eventos esportivos, inaugurações em Orlando e Flórida Central. 3. **Pontos de Interesse:** Novos restaurantes, parques, atrações ou lugares únicos que estão na moda. 4. **Notícias Locais Gerais:** Anúncios importantes da cidade, projetos de desenvolvimento ou qualquer coisa que seja tema de conversa na comunidade. Para cada tópico, formate a saída EXATAMENTE assim, numerando cada um:\n1. Título: [Um título atraente para o tópico]\nFonte: [Nome do site, blog ou fonte oficial]\nData: [Data de publicação ou data do evento]\nResumo: [Um resumo muito breve de não mais que duas frases]\n\nResponda sempre em português. Não adicione introdução ou conclusão, apenas a lista de tópicos.`
};

// FIX: Corrected typo in function name from 'fetchReal EstateNews' to 'fetchRealEstateNews'.
export const fetchRealEstateNews = async (language: Language): Promise<NewsItem[]> => {
  const prompt = newsPrompts[language];
  try {
    const response = await ai.models.generateContent({
      model: NEWS_MODEL,
      contents: prompt,
      config: { tools: [{googleSearch: {}}] }
    });
    return parseNews(response.text, language);
  } catch (error) {
    console.error("Error fetching news from Gemini:", error);
    throw new Error("Could not fetch news. Please try again.");
  }
};

const getScriptPrompt = (language: Language, newsItem: NewsItem) => {
    const prompts = {
        es: `Eres un experto en Real Estate y finanzas para la comunidad latina en EE.UU., conocido por enseñar a construir "riqueza escalonada". Tu estilo es directo, aspiracional y cercano. Tu objetivo es transformar la siguiente noticia en un guion viral y educativo para Reels/TikTok. Basado en la siguiente noticia:\nTítulo: ${newsItem.headline}\nResumen: ${newsItem.summary}\nGenera un guion en español con esta estructura estricta, con contenido conversacional, práctico y enfocado en estrategias financieras para latinos:\n\n**GUIÓN DETALLADO:**\n* **Hook (Gancho inicial - hasta 8 segundos):**\n- [Crea una pregunta o frase corta y provocadora que conecte con los miedos o aspiraciones de un latino en EE.UU. sobre dinero o vivienda. Ej: "¿Crees que necesitas $100 mil para invertir? Así empecé yo..."]\n* **Desarrollo:**\n- [Explica el punto clave de la noticia de forma sencilla, como si revelaras una estrategia o un 'secreto'. Conecta la noticia con la vida real y el objetivo de construir patrimonio. Ej: "El error que muchos cometen es pensar que... pero el sistema funciona así..."]\n* **Cierre (CTA):**\n- [Termina con una moraleja y un llamado a la acción claro, invitando a seguirte. Ej: "Construir patrimonio no es para ricos, es para el que tiene orden. Sígueme si quieres aprender cómo funciona la riqueza."]\n\n**TEXTO LIMPIO PARA AUDIO:**\n[Combina el hook, desarrollo y cierre en un párrafo fluido para la locución.]\n\n**SUGERENCIAS ADICIONALES:**\n* **Título para el video:** [Un título corto y poderoso. Ej: "El Secreto para Comprar Casa en USA"]\n* **Hashtags:**\n- #inversioninmobiliaria\n- #latinosenusa\n- #finanzaspersonales\n* **Idea de Miniatura (Thumbnail):** [Describe una imagen que llame la atención. Ej: "Persona con llaves de una casa y cara de sorpresa."]\n\nResponde SÓLO con el guion.`,
        en: `You are an expert in Real Estate and finance for the Latino community in the U.S., known for teaching how to build "scaled wealth." Your style is direct, aspirational, and relatable. Your goal is to transform the following news into a viral and educational script for Reels/TikTok. Based on the following news:\nTitle: ${newsItem.headline}\nSummary: ${newsItem.summary}\nGenerate a script in English with this strict structure, with conversational, practical content focused on financial strategies for Latinos:\n\n**DETAILED SCRIPT:**\n* **Hook (Opening hook - up to 8 seconds):**\n- [Create a short, provocative question or phrase that connects with the fears or aspirations of a Latino in the U.S. regarding money or housing. E.g., "Think you need $100k to invest? Here's how I started..."]\n* **Development:**\n- [Explain the key point of the news simply, as if revealing a strategy or 'secret'. Connect the news to real life and the goal of building wealth. E.g., "The mistake many make is thinking that... but the system works like this..."]\n* **Closing (CTA):**\n- [End with a moral and a clear, motivating call to action, inviting them to follow you. E.g., "Building wealth isn't for the rich, it's for those with a plan. Follow me to learn how wealth really works."]\n\n**CLEAN TEXT FOR AUDIO:**\n[Combine the hook, development, and closing into a fluid paragraph for the voiceover.]\n\n**ADDITIONAL SUGGESTIONS:**\n* **Video Title:** [A short, powerful title. E.g., "The Secret to Buying a Home in the USA"]\n* **Hashtags:**\n- #realestateinvesting\n- #latinosinusa\n- #personalfinance\n* **Thumbnail Idea:** [Describe an attention-grabbing image. E.g., "Person holding keys to a house with a surprised look."]\n\nRespond ONLY with the script.`,
        pt: `Você é um especialista em imóveis e finanças para a comunidade latina nos EUA, conhecido por ensinar a construir "riqueza escalonada". Seu estilo é direto, aspiracional e próximo. Seu objetivo é transformar a notícia a seguir em um roteiro viral e educativo para Reels/TikTok. Com base na seguinte notícia:\nTítulo: ${newsItem.headline}\nResumo: ${newsItem.summary}\nGere um roteiro em português com esta estrutura rígida, com conteúdo coloquial, prático e focado em estratégias financeiras para latinos:\n\n**ROTEIRO DETALHADO:**\n* **Gancho (Gancho inicial - até 8 segundos):**\n- [Crie uma pergunta ou frase curta e provocadora que se conecte com os medos ou aspirações de um latino nos EUA sobre dinheiro ou moradia. Ex: "Acha que precisa de $100 mil para investir? Foi assim que eu comecei..."]\n* **Desenvolvimento:**\n- [Explique o ponto principal da notícia de forma simples, como se estivesse revelando uma estratégia ou 'segredo'. Conecte a notícia com a vida real e o objetivo de construir patrimônio. Ex: "O erro que muitos cometem é pensar que... mas o sistema funciona assim..."]\n* **Fechamento (CTA):**\n- [Termine com uma moral e uma chamada para ação clara e motivadora, convidando a seguir. Ex: "Construir patrimônio não é para ricos, é para quem tem um plano. Siga-me para aprender como a riqueza funciona."]\n\n**TEXTO LIMPO PARA ÁUDIO:**\n[Combine o gancho, desenvolvimento e fechamento em um parágrafo fluido para a locução.]\n\n**SUGESTÕES ADICIONAIS:**\n* **Título para o vídeo:** [Um título curto e poderoso. Ex: "O Segredo para Comprar Casa nos EUA"]\n* **Hashtags:**\n- #investimentoimobiliario\n- #latinosnoseua\n- #finançaspessoais\n* **Ideia de Miniatura (Thumbnail):** [Descreva uma imagem que chame a atenção. Ex: "Pessoa segurando chaves de casa com cara de surpresa."]\n\nResponda APENAS com o roteiro.`
    };
    return prompts[language];
};

export const generateReelScript = async (newsItem: NewsItem, language: Language): Promise<Script | null> => {
    try {
        const response = await ai.models.generateContent({ model: SCRIPT_MODEL, contents: getScriptPrompt(language, newsItem) });
        return parseScript(response.text, language);
    } catch (error) {
        console.error("Error generating script from Gemini:", error);
        throw new Error("Could not generate the script. Please try again.");
    }
};

const getCustomContentPrompt = (language: Language, content: string) => {
    const prompts = {
        es: `Eres un experto en Real Estate y finanzas para la comunidad latina en EE.UU., conocido por enseñar a construir "riqueza escalonada". Tu estilo es directo, aspiracional y cercano. Transforma el siguiente contenido en un guion viral para Reels/TikTok.\nContenido: "${content}"\nSigue esta estructura estricta:\n\n**GUIÓN DETALLADO:**\n* **Hook (Gancho inicial - hasta 8 segundos):**\n- [Crea un gancho potente basado en la idea principal del contenido. Ej: "¿Sabías que una sola casa puede generarte 3 tipos de ingresos?"]\n* **Desarrollo:**\n- [Desarrolla la idea del contenido de forma sencilla y directa, como si revelaras una estrategia o un 'secreto'. Ej: "Primero: Plusvalía... Segundo: Renta... Tercero: Heloc, el secreto que nadie te cuenta..."]\n* **Cierre (CTA):**\n- [Crea una moraleja y un llamado a la acción claro. Ej: "Riqueza no es suerte, es rutina. Sígueme para aprender a construir tu riqueza escalonada."]\n\n**TEXTO LIMPIO PARA AUDIO:**\n[Combina todo en un texto fluido para la locución.]\n\n**SUGERENCIAS ADICIONALES:**\n* **Título para el video:** [Título corto y atractivo]\n* **Hashtags:**\n- #inversioninmobiliaria\n- #educacionfinanciera\n- #latinosenusa\n* **Idea de Miniatura (Thumbnail):** [Describe una imagen relevante y llamativa]\n\nResponde SÓLO con el guion.`,
        en: `You are an expert in Real Estate and finance for the Latino community in the U.S., known for teaching "scaled wealth." Your style is direct and aspirational. Transform the following content into a viral script for Reels/TikTok.\nContent: "${content}"\nFollow this strict structure:\n\n**DETAILED SCRIPT:**\n* **Hook (Opening hook - up to 8 seconds):**\n- [Create a powerful hook based on the main idea. E.g., "Did you know one house can generate 3 types of income?"]\n* **Development:**\n- [Develop the core idea simply and directly, as if revealing a strategy. E.g., "First: Appreciation... Second: Rent... Third: HELOC, the secret no one tells you..."]\n* **Closing (CTA):**\n- [Create a moral and a clear call to action. E.g., "Wealth isn't luck, it's a routine. Follow me to learn how to build scaled wealth."]\n\n**CLEAN TEXT FOR AUDIO:**\n[Combine everything into a fluid text for the voiceover.]\n\n**ADDITIONAL SUGGESTIONS:**\n* **Video Title:** [Short, catchy title]\n* **Hashtags:**\n- #realestateinvesting\n- #financialliteracy\n- #wealthbuilding\n* **Thumbnail Idea:** [Describe a relevant and striking image]\n\nRespond ONLY with the script.`,
        pt: `Você é um especialista em imóveis e finanças para a comunidade latina nos EUA, conhecido por ensinar "riqueza escalonada". Seu estilo é direto e aspiracional. Transforme o conteúdo a seguir em um roteiro viral para Reels/TikTok.\nConteúdo: "${content}"\nSiga esta estrutura rígida:\n\n**ROTEIRO DETALHADO:**\n* **Gancho (Gancho inicial - até 8 segundos):**\n- [Crie um gancho poderoso com base na ideia principal. Ex: "Você sabia que uma única casa pode gerar 3 tipos de renda?"]\n* **Desenvolvimento:**\n- [Desenvolva a ideia central de forma simples e direta, como se estivesse revelando uma estratégia. Ex: "Primeiro: Valorização... Segundo: Aluguel... Terceiro: HELOC, o segredo que ninguém te conta..."]\n* **Fechamento (CTA):**\n- [Crie uma moral e uma chamada para ação clara. Ex: "Riqueza não é sorte, é rotina. Siga-me para aprender a construir riqueza escalonada."]\n\n**TEXTO LIMPO PARA ÁUDIO:**\n[Combine tudo em um texto fluido para a locução.]\n\n**SUGESTÕES ADICIONAIS:**\n* **Título para o vídeo:** [Título curto e cativante]\n* **Hashtags:**\n- #investimentoimobiliario\n- #educaçãofinanceira\n- #construirriqueza\n* **Ideia de Miniatura (Thumbnail):** [Descreva uma imagem relevante e chamativa]\n\nResponda APENAS com o roteiro.`
    };
    return prompts[language];
}

export const generateScriptFromCustomContent = async (content: string, language: Language): Promise<Script | null> => {
    try {
        const response = await ai.models.generateContent({ model: SCRIPT_MODEL, contents: getCustomContentPrompt(language, content) });
        return parseScript(response.text, language);
    } catch (error) {
        console.error("Error generating script from custom content:", error);
        throw new Error("Could not generate script from your content. Please try again.");
    }
};

export const generateScriptFromVideo = async (videoBase64: string, mimeType: string, language: Language): Promise<Script | null> => {
    const transcriptionPrompts = {
        es: 'Transcribe el audio de este video de forma precisa. Responde únicamente con la transcripción en español.',
        en: 'Transcribe the audio from this video accurately. Respond only with the transcription in English.',
        pt: 'Transcreva o áudio deste vídeo com precisão. Responda apenas com a transcrição em português.'
    };
    let transcription = '';
    try {
        const transcribeResponse = await ai.models.generateContent({
            model: VIDEO_MODEL,
            contents: { parts: [{ inlineData: { data: videoBase64, mimeType: mimeType } }, { text: transcriptionPrompts[language] }] },
        });
        transcription = transcribeResponse.text;
        if (!transcription || transcription.trim().length === 0) throw new Error("Video transcription was empty. Make sure the video has clear audio.");
    } catch (error) {
        console.error("Error transcribing video with Gemini:", error);
        if (error instanceof Error && error.message.includes("Video transcription was empty")) throw error;
        throw new Error("Could not transcribe the video. Please try a different file.");
    }
    return generateScriptFromCustomContent(transcription, language);
};

const getEditPrompt = (language: Language, newsItem: NewsItem, currentScript: Script, editCommand: string) => {
    const prompts = {
        es: `Eres NEWS→REELS, un asistente experto en edición de guiones. Tu tarea es tomar un guion existente y modificarlo según el comando del usuario, manteniendo el tono viral, directo y educativo para la comunidad latina en EE.UU.\nNoticia Original: ${newsItem.headline}\nGuion Actual: ${JSON.stringify(currentScript.detailedScript)}\nComando de Edición: "${editCommand}"\nReescribe el guion completo en español aplicando el cambio. MANTÉN LA ESTRUTURA EXACTA del formato original, incluyendo todos los encabezados y el estilo "riqueza escalonada". Responde SÓLO con el guion reescrito.`,
        en: `You are NEWS→REELS, an expert script editing assistant. Your task is to take an existing script and modify it based on the user's command, maintaining the viral, direct, and educational tone for the Latino community in the U.S.\nOriginal News: ${newsItem.headline}\nCurrent Script: ${JSON.stringify(currentScript.detailedScript)}\nEdit Command: "${editCommand}"\nRewrite the entire script in English applying the change. MAINTAIN THE EXACT STRUCTURE of the original format, including all headers and the "scaled wealth" style. Respond ONLY with the rewritten script.`,
        pt: `Você é NEWS→REELS, um assistente especialista em edição de roteiros. Sua tarefa é pegar um roteiro existente e modificá-lo com base no comando do usuário, mantendo o tom viral, direto e educativo para a comunidade latina nos EUA.\nNotícia Original: ${newsItem.headline}\nRoteiro Atual: ${JSON.stringify(currentScript.detailedScript)}\nComando de Edição: "${editCommand}"\nReescreva o roteiro completo em português aplicando a alteração. MANTENHA A ESTRUTURA EXATA do formato original, incluindo todos os cabeçalhos e o estilo "riqueza escalonada". Responda APENAS com o roteiro reescrito.`
    };
    return prompts[language];
}

export const editReelScript = async (newsItem: NewsItem, currentScript: Script, editCommand: string, language: Language): Promise<Script | null> => {
    try {
        const response = await ai.models.generateContent({ model: SCRIPT_MODEL, contents: getEditPrompt(language, newsItem, currentScript, editCommand) });
        return parseScript(response.text, language);
    } catch (error) {
        console.error("Error editing script with Gemini:", error);
        throw new Error("Could not edit the script. Please try again.");
    }
};

export const generateSpeech = async (text: string, language: Language): Promise<string | null> => {
  const ttsPrompts = {
      es: `Di lo siguiente con un tono enérgico y profesional: ${text}`,
      en: `Say the following in an energetic and professional tone: ${text}`,
      pt: `Diga o seguinte em um tom energético e profissional: ${text}`
  };
  try {
    const response = await ai.models.generateContent({
      model: TTS_MODEL,
      contents: [{ parts: [{ text: ttsPrompts[language] }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
      },
    });
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) throw new Error("No audio data received from API.");
    return base64Audio;
  } catch (error) {
    console.error("Error generating speech from Gemini:", error);
    throw new Error("Could not generate the audio. Please try again.");
  }
};